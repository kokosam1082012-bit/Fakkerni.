const COLORS = ["red","blue","green","yellow"];
const COLOR_AR = {red:"أحمر",blue:"أزرق",green:"أخضر",yellow:"أصفر"};
const ICONS = {skip:"⊘",reverse:"⇄",draw2:"+2",wild:"✦",draw4:"+4"};
const EMOJIS = ["🦊","🐼","🐸"];
let deck=[], discard=[], players=[], current=0, direction=1, chosenColor="red", waitingColor=false, drawnThisTurn=false, gameOver=false, unoCalled=false, lastPlayed=null;

const $ = id => document.getElementById(id);
function makeDeck(){
  const d=[];
  COLORS.forEach(color=>{
    d.push({color,value:"0"});
    for(let n=1;n<=9;n++){d.push({color,value:String(n)},{color,value:String(n)});}
    ["skip","reverse","draw2"].forEach(value=>{d.push({color,value},{color,value});});
  });
  for(let i=0;i<4;i++){d.push({color:"wild",value:"wild"},{color:"wild",value:"draw4"});}
  return shuffle(d);
}
function shuffle(a){for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
function startGame(){
  deck=makeDeck();discard=[];players=[{name:"أنت",hand:[],human:true,emoji:"👑"},{name:"ليلى",hand:[],emoji:"🦊"},{name:"كريم",hand:[],emoji:"🐼"},{name:"نور",hand:[],emoji:"🐸"}];
  current=0;direction=1;chosenColor="red";waitingColor=false;drawnThisTurn=false;gameOver=false;unoCalled=false;lastPlayed=null;
  players.forEach(p=>{for(let i=0;i<7;i++)p.hand.push(drawCard());});
  let first=drawCard();while(first.color==="wild"){deck.unshift(first);first=drawCard();}
  discard.push(first);chosenColor=first.color;
  if(first.value==="reverse")direction=-1;
  if(first.value==="skip")current=1;
  if(first.value==="draw2"){players[1].hand.push(drawCard(),drawCard());current=1;}
  render();if(current!==0)setTimeout(botTurn,650);
}
function drawCard(){if(!deck.length){if(discard.length>1){const top=discard.pop();deck=shuffle(discard.splice(0));discard=[top];}else{return {color:COLORS[Math.floor(Math.random()*4)],value:String(1+Math.floor(Math.random()*9))};}}return deck.pop();}
function topCard(){return discard[discard.length-1];}
function canPlay(card){const top=topCard();return card.color==="wild"||card.color===chosenColor||card.value===top.value;}
function cardText(card){return /^[0-9]$/.test(card.value)?card.value:(ICONS[card.value]||card.value);}
function cardElement(card,index,interactive=false){
  const el=document.createElement("button");el.className=`playing-card ${card.color}`;el.type="button";
  el.style.setProperty("--tilt",`${(index-(players[0].hand.length-1)/2)*1.4}deg`);
  el.innerHTML=`<span class="corner top">${cardText(card)}</span><span class="card-symbol">${cardText(card)}</span><span class="corner bottom">${cardText(card)}</span>`;
  if(interactive){const playable=current===0&&!gameOver&&!waitingColor&&canPlay(card);el.disabled=!playable;el.setAttribute("aria-label",`كارت ${COLOR_AR[card.color]||"تغيير لون"} ${cardText(card)}`);el.addEventListener("click",()=>playCard(0,index));}
  return el;
}
function render(){
  $("deckCount").textContent=deck.length;
  $("handCount").textContent=`${players[0].hand.length} ${players[0].hand.length===1?"كارت":"كروت"} في إيدك`;
  const hand=$("playerHand");hand.innerHTML="";players[0].hand.forEach((c,i)=>hand.appendChild(cardElement(c,i,true)));
  const opp=$("opponents");opp.innerHTML="";
  players.slice(1).forEach((p,i)=>{const box=document.createElement("div");box.className="opponent";box.innerHTML=`<div class="opponent-avatar">${p.emoji}</div><div><strong>${p.name}</strong><small>${p.hand.length} كروت</small></div><div class="opponent-cards">${Array.from({length:Math.min(p.hand.length,5)},()=>'<i class="mini-back"></i>').join("")}</div>`;opp.appendChild(box);});
  const top=topCard();const old=$("discardCard");const newCard=cardElement(top,0,false);newCard.id="discardCard";newCard.classList.add("large-card");old.replaceWith(newCard);
  $("activeColor").querySelector("i").style.background=`var(--${chosenColor})`;
  $("activeColor").querySelector("span").textContent=COLOR_AR[chosenColor]||"اختيار اللون";
  $("turnLabel").textContent=current===0?"دورك أنت":`دور ${players[current].name}`;
  $("tableMessage").textContent=gameOver?"انتهت الجولة":current===0?(drawnThisTurn?"اسحب كارتًا مناسبًا أو اضغط إنهاء الدور.":"دورك! العب كارت مناسب أو اسحب."):`${players[current].name} بيفكر...`;
  $("drawPile").style.opacity=(current===0&&!gameOver&&!waitingColor)?"1":".75";
}
function playCard(playerIndex,handIndex){
  if(gameOver||playerIndex!==current||waitingColor)return;
  const p=players[playerIndex],card=p.hand[handIndex];if(!card||!canPlay(card))return;
  p.hand.splice(handIndex,1);discard.push(card);lastPlayed=card;drawnThisTurn=false;
  if(p.hand.length===1&&!unoCalled&&playerIndex===0){/* UNO reminder is intentionally non-blocking */}
  if(p.hand.length===0){finishGame(playerIndex);return;}
  if(card.color==="wild"){waitingColor=true;if(playerIndex===0){render();$("colorModal").classList.remove("hidden");return;}chosenColor=COLORS[Math.floor(Math.random()*4)];waitingColor=false;}
  else chosenColor=card.color;
  applyEffect(card,playerIndex);
}
function applyEffect(card,playerIndex){
  if(card.value==="reverse"){direction*=-1;if(players.length===2)advanceTurn();}
  else if(card.value==="skip"){advanceTurn();if(!gameOver)advanceTurn();}
  else if(card.value==="draw2"){const next=nextIndex();players[next].hand.push(drawCard(),drawCard());advanceTurn();if(!gameOver)advanceTurn();}
  else if(card.value==="draw4"){const next=nextIndex();for(let i=0;i<4;i++)players[next].hand.push(drawCard());advanceTurn();if(!gameOver)advanceTurn();}
  else advanceTurn();
  render();if(current!==0&&!gameOver)setTimeout(botTurn,700);
}
function nextIndex(){return (current+direction+players.length)%players.length;}
function advanceTurn(){current=(current+direction+players.length)%players.length;unoCalled=false;}
function drawForHuman(){
  if(current!==0||gameOver||waitingColor)return;
  if(drawnThisTurn){endHumanTurn();return;}
  players[0].hand.push(drawCard());drawnThisTurn=true;render();
  const newIndex=players[0].hand.length-1;
  if(canPlay(players[0].hand[newIndex])){$("tableMessage").textContent="الكارت الجديد ينفع تلعبه، اختاره من إيدك.";}
  else $("tableMessage").textContent="الكارت مش مناسب. اضغط على رزمة السحب لإنهاء دورك.";
}
function endHumanTurn(){if(current!==0||gameOver)return;drawnThisTurn=false;advanceTurn();render();if(current!==0)setTimeout(botTurn,650);}
function botTurn(){
  if(gameOver||current===0)return;
  const p=players[current];let options=p.hand.map((c,i)=>({c,i})).filter(x=>canPlay(x.c));
  options.sort((a,b)=>{const score=c=>c.value==="draw4"?8:c.value==="draw2"?7:["skip","reverse"].includes(c.value)?5:c.color==="wild"?4:0;return score(b.c)-score(a.c);});
  if(!options.length){p.hand.push(drawCard());const drawn=p.hand[p.hand.length-1];if(canPlay(drawn)){setTimeout(()=>{if(!gameOver&&current!==0)playCard(current,p.hand.length-1);},450);return;}advanceTurn();render();if(current!==0)setTimeout(botTurn,550);return;}
  let pick=options[0];if(options.length>1)pick=options[Math.floor(Math.random()*Math.min(2,options.length))];
  playCard(current,pick.i);
}
function finishGame(winner){
  gameOver=true;render();$("resultIcon").textContent=winner===0?"🏆":"🎮";$("resultTitle").textContent=winner===0?"كسبت يا بطل!":"حظ أوفر المرة الجاية";$("resultText").textContent=winner===0?"خلصت كل الكروت قبل المنافسين. تستاهل الفوز!":`${players[winner].name} خلّص كروته الأول. جرّب تاني وخد بالك من الكروت الخاصة.`;$("messageModal").classList.remove("hidden");
}
$("drawPile").addEventListener("click",drawForHuman);$("drawPile").addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();drawForHuman();}});
$("unoBtn").addEventListener("click",()=>{if(current!==0||gameOver)return;unoCalled=true;$("tableMessage").textContent=players[0].hand.length===1?"UNO! اتقالت في وقتها!":"خلي زر UNO لحد ما يبقى معاك كارت واحد.";});
document.querySelectorAll(".color-choice").forEach(btn=>btn.addEventListener("click",()=>{chosenColor=btn.dataset.color;waitingColor=false;$("colorModal").classList.add("hidden");applyEffect(lastPlayed,0);}));
$("closeColor").addEventListener("click",()=>{if(waitingColor){chosenColor=COLORS[Math.floor(Math.random()*4)];waitingColor=false;$("colorModal").classList.add("hidden");applyEffect(lastPlayed,0);}});
$("restartBtn").addEventListener("click",startGame);$("playAgainBtn").addEventListener("click",()=>{$("messageModal").classList.add("hidden");startGame();});
$("rulesBtn").addEventListener("click",()=>$("rulesModal").classList.remove("hidden"));$("closeRules").addEventListener("click",()=>$("rulesModal").classList.add("hidden"));
$("rulesModal").addEventListener("click",e=>{if(e.target===$("rulesModal"))$("rulesModal").classList.add("hidden");});
$("messageModal").addEventListener("click",e=>{if(e.target===$("messageModal")){$("messageModal").classList.add("hidden");startGame();}});
startGame();