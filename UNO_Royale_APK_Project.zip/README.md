# UNO Royale → APK

1. ارفع محتوى المجلد ده كله على repo جديد في GitHub (فرع main).
2. روح تبويب Actions ← Build APK ← استنى ينتهي (٣-٥ دقايق).
3. نزّل الملف من Artifacts: UNO-Royale-APK ← app-debug.apk وثبّته.

لعمل تعديل: غيّر الملفات داخل www/ وارفعها، والـ APK بيتبني تلقائي.
الخطوط (اختياري للشكل الأصلي): حط Cairo.woff2 و Outfit.woff2 داخل www/fonts/
