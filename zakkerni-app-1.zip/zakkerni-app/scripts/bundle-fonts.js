// يحمّل خطوط fontsource ويضمّها في www/fonts أثناء البناء (أي خط يفشل يتجاهله والتطبيق يرجع لـ Cairo)
const {execSync}=require('child_process'),fs=require('fs');
const F=['el-messiri','noto-naskh-arabic','changa','reem-kufi'];
fs.mkdirSync('www/fonts',{recursive:true});let css='';
for(const f of F){try{
  const tmp=fs.mkdtempSync('/tmp/fnt-');
  execSync(`npm pack @fontsource-variable/${f} --pack-destination ${tmp}`,{stdio:'pipe'});
  const tgz=fs.readdirSync(tmp).find(x=>x.endsWith('.tgz'));
  execSync(`tar -xzf ${tmp}/${tgz} -C ${tmp}`);
  const base=tmp+'/package/',src=fs.readFileSync(base+'wght.css','utf8');
  for(const b of src.match(/@font-face\s*{[^}]*}/g)||[]){
    const m=b.match(/url\(\.\/files\/([^)]+\.woff2)\)/);
    if(!m||!/-(arabic|latin|latin-ext)-wght-normal/.test(m[1]))continue;
    fs.copyFileSync(base+'files/'+m[1],'www/fonts/'+m[1]);
    css+=b.replace(/,\s*url\([^)]*\.woff\)\s*format\('woff'\)/,'').replace('./files/','fonts/')+'\n';
  }
  console.log('ok',f);
}catch(e){console.log('skip',f,e.message)}}
fs.writeFileSync('www/fonts.css',css);
